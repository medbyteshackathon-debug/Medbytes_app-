import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type Priority = 'critical' | 'high' | 'medium' | 'low';

export interface MotherForm {
  id: string;
  name: string;
  age: string;
  trimester: string;
  firstBaby: boolean;
  numberOfBabies: string;
  symptoms: {
    bleeding?: string;
    headache?: string;
    swelling?: string;
    dizziness?: string;
    cramping?: string;
    fever?: string;
    fetalMovement?: string;
  };
  healthConditions: {
    diabetes: boolean;
    cancer: boolean;
    kidney: boolean;
    anemia: boolean;
    covid: boolean;
    heartDisease: boolean;
  };
  locationConditions: {
    displaced: boolean;
    foodShortage: boolean;
    exposureToBombing: boolean;
    ongoingPregnancyCare: boolean;
    diseaseOutbreak: boolean;
  };
  additionalInfo: string;
  timestamp: string;
  priority: Priority;
}

interface MotherStore {
  mothers: MotherForm[];
  addMother: (mother: MotherForm) => void;
  updateMother: (id: string, mother: MotherForm) => void;
  deleteMother: (id: string) => void;
  getMother: (id: string) => MotherForm | undefined;
  clearMothers: () => void;
}

// Priority calculation function
export function calculatePriority(form: Omit<MotherForm, 'id' | 'timestamp' | 'priority'>): Priority {
  let score = 0;

  // Age risk
  if (form.age === 'under18' || form.age === 'over35') {
    score += 2;
  }

  // Trimester risk
  if (form.trimester === 'firstTrimester' || form.trimester === 'thirdTrimester') {
    score += 1;
  }

  // Multiple babies risk
  if (form.numberOfBabies === 'twins') score += 1;
  if (form.numberOfBabies === 'triplets') score += 2;
  if (form.numberOfBabies === 'moreThan3') score += 3;

  // Symptoms
  const { symptoms } = form;
  if (symptoms.bleeding === 'high') score += 4;
  else if (symptoms.bleeding === 'medium') score += 2;
  else if (symptoms.bleeding === 'low') score += 1;

  if (symptoms.headache === 'high') score += 2;
  else if (symptoms.headache === 'medium') score += 1;

  if (symptoms.swelling === 'high') score += 2;
  else if (symptoms.swelling === 'medium') score += 1;

  if (symptoms.dizziness === 'constant') score += 3;
  else if (symptoms.dizziness === 'medium') score += 1;

  if (symptoms.cramping === 'high') score += 3;
  else if (symptoms.cramping === 'medium') score += 1;

  if (symptoms.fever === 'high') score += 3;
  else if (symptoms.fever === 'medium') score += 1;

  if (symptoms.fetalMovement === 'none') score += 5;
  else if (symptoms.fetalMovement === 'reduced') score += 2;
  else if (symptoms.fetalMovement === 'excessive') score += 1;

  // Health conditions
  const { healthConditions } = form;
  if (healthConditions.diabetes) score += 2;
  if (healthConditions.cancer) score += 3;
  if (healthConditions.kidney) score += 2;
  if (healthConditions.anemia) score += 2;
  if (healthConditions.covid) score += 2;
  if (healthConditions.heartDisease) score += 3;

  // Location conditions
  const { locationConditions } = form;
  if (locationConditions.displaced) score += 2;
  if (locationConditions.foodShortage) score += 2;
  if (locationConditions.exposureToBombing) score += 3;
  if (!locationConditions.ongoingPregnancyCare) score += 1;
  if (locationConditions.diseaseOutbreak) score += 2;

  // Determine priority based on score
  if (score >= 12) return 'critical';
  if (score >= 7) return 'high';
  if (score >= 3) return 'medium';
  return 'low';
}

export function generateId(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = 'MOM-';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export const useMotherStore = create<MotherStore>()(
  persist(
    (set, get) => ({
      mothers: [],
      addMother: (mother) =>
        set((state) => ({
          mothers: [...state.mothers, mother],
        })),
      updateMother: (id, mother) =>
        set((state) => ({
          mothers: state.mothers.map((m) => (m.id === id ? mother : m)),
        })),
      deleteMother: (id) =>
        set((state) => ({
          mothers: state.mothers.filter((m) => m.id !== id),
        })),
      getMother: (id) => get().mothers.find((m) => m.id === id),
      clearMothers: () => set({ mothers: [] }),
    }),
    {
      name: 'mother-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
