import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MotherForm } from './mother-store';

export interface ReceivedForm extends MotherForm {
  completed: boolean;
  completedAt?: string;
}

interface ResponderStore {
  receivedForms: ReceivedForm[];
  addReceivedForm: (form: MotherForm) => void;
  markAsCompleted: (id: string) => void;
  markAsIncomplete: (id: string) => void;
  clearReceivedForms: () => void;
  getFormById: (id: string) => ReceivedForm | undefined;
  hasForm: (id: string) => boolean;
}

export const useResponderStore = create<ResponderStore>()(
  persist(
    (set, get) => ({
      receivedForms: [],
      addReceivedForm: (form) => {
        const exists = get().receivedForms.some((f) => f.id === form.id);
        if (!exists) {
          set((state) => ({
            receivedForms: [...state.receivedForms, { ...form, completed: false }],
          }));
        }
      },
      markAsCompleted: (id) =>
        set((state) => ({
          receivedForms: state.receivedForms.map((f) =>
            f.id === id ? { ...f, completed: true, completedAt: new Date().toISOString() } : f
          ),
        })),
      markAsIncomplete: (id) =>
        set((state) => ({
          receivedForms: state.receivedForms.map((f) =>
            f.id === id ? { ...f, completed: false, completedAt: undefined } : f
          ),
        })),
      clearReceivedForms: () => set({ receivedForms: [] }),
      getFormById: (id) => get().receivedForms.find((f) => f.id === id),
      hasForm: (id) => get().receivedForms.some((f) => f.id === id),
    }),
    {
      name: 'responder-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
