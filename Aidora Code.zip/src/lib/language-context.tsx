import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Homescreen
    selectLanguage: 'Select Language',
    english: 'English',
    arabic: 'العربية',
    mother: 'Mother',
    firstResponder: 'First Responder',
    chooseRole: 'Choose Your Role',

    // Navigation
    form: 'Form',
    yourStatus: 'Your Status',
    information: 'Information',
    dashboard: 'Dashboard',
    qrCode: 'QR Code',
    status: 'Status',
    info: 'Info',

    // Form categories
    name: 'Name',
    age: 'Age',
    trimester: 'Trimester',
    firstBaby: 'First Baby?',
    numberOfBabies: 'Number of Babies Conceived',
    commonSymptoms: 'Common Symptoms',
    healthConditions: 'Health Conditions',
    locationConditions: 'Location Conditions',
    additionalInfo: 'Additional Information',

    // Age options
    under18: '18 and under',
    age18to35: '18-35',
    over35: '35 and over',

    // Trimester options
    firstTrimester: 'First trimester',
    secondTrimester: 'Second trimester',
    thirdTrimester: 'Third trimester',

    // Baby count
    oneBaby: 'One baby',
    twins: 'Twins',
    triplets: 'Triplets',
    moreThan3: 'More than 3',

    // Symptoms
    bleeding: 'Bleeding?',
    headache: 'Headache?',
    swelling: 'Swelling',
    dizziness: 'Dizziness or Vomiting?',
    cramping: 'Cramping',
    fever: 'Fever',
    fetalMovement: 'Fetal Movement?',

    // Symptom levels
    high: 'High',
    medium: 'Medium',
    low: 'Low',
    constant: 'Constant',
    none: 'None',
    reduced: 'Reduced',
    normal: 'Normal',
    excessive: 'Excessive',

    // Health conditions
    diabetes: 'Diabetes',
    cancer: 'Cancer',
    kidney: 'Kidney',
    anemia: 'Anemia',
    covid: 'Covid',
    heartDisease: 'Heart Disease',

    // Location conditions
    displaced: 'Displaced',
    foodShortage: 'Food shortage',
    exposureToBombing: 'Exposure to bombing',
    ongoingPregnancyCare: 'Ongoing pregnancy care',
    diseaseOutbreak: 'Disease outbreak',

    // Form actions
    enterName: 'Enter your name',
    extraDetails: 'Extra details about pregnancy, symptoms, condition, or other.',
    submitForm: 'Submit Form',
    yes: 'Yes',
    no: 'No',

    // Priority levels
    critical: 'Critical',
    priorityHigh: 'High',
    priorityMedium: 'Medium',
    priorityLow: 'Low',

    // Status screen
    noFormsSubmitted: 'No forms submitted yet',
    fillFormFirst: 'Fill out the form to see your status',
    priority: 'Priority',
    submittedAt: 'Submitted at',
    viewQRCode: 'View QR Code',

    // Info screen
    priorityExplanations: 'Priority Explanations',
    criticalDesc: 'Requires immediate, time-intensive medical attention. Relocate to safe zone hospital immediately.',
    highDesc: 'Urgent attention needed. Seek medical care within 5-7 hours.',
    mediumDesc: 'Should be evaluated soon. Schedule appointment within days.',
    lowDesc: 'Routine follow-up. Standard care. Relocate to prevent further complications.',

    symptomDefinitions: 'Symptom Definitions',
    healthConditionDefinitions: 'Health Condition Definitions',
    locationConditionDefinitions: 'Location Condition Definitions',
    trimesterDefinitions: 'Trimester Definitions',

    logout: 'Logout',

    // First Responder
    login: 'Login',
    email: 'Email',
    password: 'Password',
    loginButton: 'Login',
    enterEmail: 'Enter your email',
    enterPassword: 'Enter your password',

    // Dashboard
    receivedForms: 'Received Forms',
    noFormsReceived: 'No forms received yet',
    scanQRToReceive: 'Scan QR codes to receive forms',

    // QR Scanner
    scanQRCode: 'Scan QR Code',
    pointCamera: 'Point camera at QR code',

    // Status summary
    statusSummary: 'Status Summary',
    criticalCases: 'Critical Cases',
    highCases: 'High Priority Cases',
    mediumCases: 'Medium Priority Cases',
    lowCases: 'Low Priority Cases',

    // First Responder Info
    responderActions: 'First Responder Actions',
    criticalActions: 'Critical Priority Actions',
    highActions: 'High Priority Actions',
    mediumActions: 'Medium Priority Actions',
    lowActions: 'Low Priority Actions',
  },
  ar: {
    // Homescreen
    selectLanguage: 'اختر اللغة',
    english: 'English',
    arabic: 'العربية',
    mother: 'أم',
    firstResponder: 'المستجيب الأول',
    chooseRole: 'اختر دورك',

    // Navigation
    form: 'نموذج',
    yourStatus: 'حالتك',
    information: 'معلومات',
    dashboard: 'لوحة القيادة',
    qrCode: 'رمز QR',
    status: 'الحالة',
    info: 'معلومات',

    // Form categories
    name: 'الاسم',
    age: 'العمر',
    trimester: 'الثلث',
    firstBaby: 'الطفل الأول؟',
    numberOfBabies: 'عدد الأطفال',
    commonSymptoms: 'الأعراض الشائعة',
    healthConditions: 'الحالات الصحية',
    locationConditions: 'ظروف الموقع',
    additionalInfo: 'معلومات إضافية',

    // Age options
    under18: '18 وأقل',
    age18to35: '18-35',
    over35: '35 وأكثر',

    // Trimester options
    firstTrimester: 'الثلث الأول',
    secondTrimester: 'الثلث الثاني',
    thirdTrimester: 'الثلث الثالث',

    // Baby count
    oneBaby: 'طفل واحد',
    twins: 'توأم',
    triplets: 'ثلاثة توائم',
    moreThan3: 'أكثر من 3',

    // Symptoms
    bleeding: 'نزيف؟',
    headache: 'صداع؟',
    swelling: 'تورم',
    dizziness: 'دوخة أو قيء؟',
    cramping: 'تشنجات',
    fever: 'حمى',
    fetalMovement: 'حركة الجنين؟',

    // Symptom levels
    high: 'عالي',
    medium: 'متوسط',
    low: 'منخفض',
    constant: 'مستمر',
    none: 'لا يوجد',
    reduced: 'منخفض',
    normal: 'طبيعي',
    excessive: 'مفرط',

    // Health conditions
    diabetes: 'السكري',
    cancer: 'السرطان',
    kidney: 'الكلى',
    anemia: 'فقر الدم',
    covid: 'كوفيد',
    heartDisease: 'أمراض القلب',

    // Location conditions
    displaced: 'نازح',
    foodShortage: 'نقص الغذاء',
    exposureToBombing: 'التعرض للقصف',
    ongoingPregnancyCare: 'رعاية الحمل المستمرة',
    diseaseOutbreak: 'تفشي المرض',

    // Form actions
    enterName: 'أدخل اسمك',
    extraDetails: 'تفاصيل إضافية عن الحمل أو الأعراض أو الحالة أو غيرها.',
    submitForm: 'إرسال النموذج',
    yes: 'نعم',
    no: 'لا',

    // Priority levels
    critical: 'حرج',
    priorityHigh: 'عالي',
    priorityMedium: 'متوسط',
    priorityLow: 'منخفض',

    // Status screen
    noFormsSubmitted: 'لم يتم تقديم أي نماذج بعد',
    fillFormFirst: 'املأ النموذج لرؤية حالتك',
    priority: 'الأولوية',
    submittedAt: 'تم التقديم في',
    viewQRCode: 'عرض رمز QR',

    // Info screen
    priorityExplanations: 'شرح الأولويات',
    criticalDesc: 'يتطلب اهتمامًا طبيًا فوريًا ومكثفًا. انتقل إلى مستشفى المنطقة الآمنة فورًا.',
    highDesc: 'يحتاج إلى اهتمام عاجل. اطلب الرعاية الطبية خلال 5-7 ساعات.',
    mediumDesc: 'يجب تقييمه قريبًا. حدد موعدًا خلال أيام.',
    lowDesc: 'متابعة روتينية. رعاية قياسية. انتقل لمنع المزيد من المضاعفات.',

    symptomDefinitions: 'تعريفات الأعراض',
    healthConditionDefinitions: 'تعريفات الحالات الصحية',
    locationConditionDefinitions: 'تعريفات ظروف الموقع',
    trimesterDefinitions: 'تعريفات الثلث',

    logout: 'تسجيل الخروج',

    // First Responder
    login: 'تسجيل الدخول',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    loginButton: 'تسجيل الدخول',
    enterEmail: 'أدخل بريدك الإلكتروني',
    enterPassword: 'أدخل كلمة المرور',

    // Dashboard
    receivedForms: 'النماذج المستلمة',
    noFormsReceived: 'لم يتم استلام أي نماذج بعد',
    scanQRToReceive: 'امسح رموز QR لاستلام النماذج',

    // QR Scanner
    scanQRCode: 'مسح رمز QR',
    pointCamera: 'وجه الكاميرا نحو رمز QR',

    // Status summary
    statusSummary: 'ملخص الحالة',
    criticalCases: 'الحالات الحرجة',
    highCases: 'حالات الأولوية العالية',
    mediumCases: 'حالات الأولوية المتوسطة',
    lowCases: 'حالات الأولوية المنخفضة',

    // First Responder Info
    responderActions: 'إجراءات المستجيب الأول',
    criticalActions: 'إجراءات الأولوية الحرجة',
    highActions: 'إجراءات الأولوية العالية',
    mediumActions: 'إجراءات الأولوية المتوسطة',
    lowActions: 'إجراءات الأولوية المنخفضة',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
