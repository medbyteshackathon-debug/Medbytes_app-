import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLanguage } from '@/lib/language-context';
import { Heart, Shield, Globe } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function HomeScreen() {
  const router = useRouter();
  const { language, setLanguage, t } = useLanguage();

  return (
    <View className="flex-1 bg-slate-900">
      <LinearGradient
        colors={['#1e293b', '#0f172a', '#020617']}
        style={{ flex: 1 }}
      >
        <SafeAreaView className="flex-1">
          {/* Language Selector */}
          <View className="flex-row justify-end px-6 pt-4">
            <View className="flex-row bg-slate-800/80 rounded-full p-1">
              <Pressable
                onPress={() => setLanguage('en')}
                className={`px-4 py-2 rounded-full flex-row items-center ${
                  language === 'en' ? 'bg-teal-500' : ''
                }`}
              >
                <Globe size={14} color={language === 'en' ? '#fff' : '#94a3b8'} />
                <Text
                  className={`ml-2 text-sm font-medium ${
                    language === 'en' ? 'text-white' : 'text-slate-400'
                  }`}
                >
                  {t('english')}
                </Text>
              </Pressable>
              <Pressable
                onPress={() => setLanguage('ar')}
                className={`px-4 py-2 rounded-full flex-row items-center ${
                  language === 'ar' ? 'bg-teal-500' : ''
                }`}
              >
                <Text
                  className={`text-sm font-medium ${
                    language === 'ar' ? 'text-white' : 'text-slate-400'
                  }`}
                >
                  {t('arabic')}
                </Text>
              </Pressable>
            </View>
          </View>

          {/* Main Content */}
          <View className="flex-1 justify-center items-center px-6">
            {/* Logo/Brand */}
            <View className="mb-12">
              <Text className="text-5xl font-bold text-white text-center tracking-tight">
                Aidora
              </Text>
              <Text className="text-slate-400 text-center mt-2 text-lg">
                {t('chooseRole')}
              </Text>
            </View>

            {/* Role Selection */}
            <View className="w-full gap-4">
              {/* Mother Option */}
              <Pressable
                onPress={() => router.push('/mother')}
                className="active:scale-[0.98]"
              >
                <LinearGradient
                  colors={['#14b8a6', '#0d9488', '#0f766e']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{
                    borderRadius: 20,
                    padding: 24,
                  }}
                >
                  <View className="flex-row items-center">
                    <View className="w-16 h-16 bg-white/20 rounded-full items-center justify-center">
                      <Heart size={32} color="#fff" fill="#fff" />
                    </View>
                    <View className="ml-4 flex-1">
                      <Text className="text-white text-2xl font-bold">
                        {t('mother')}
                      </Text>
                      <Text className="text-white/70 text-sm mt-1">
                        {language === 'en'
                          ? 'Track your pregnancy and get help'
                          : 'تتبعي حملك واحصلي على المساعدة'}
                      </Text>
                    </View>
                  </View>
                </LinearGradient>
              </Pressable>

              {/* First Responder Option */}
              <Pressable
                onPress={() => router.push('/responder-login')}
                className="active:scale-[0.98]"
              >
                <LinearGradient
                  colors={['#3b82f6', '#2563eb', '#1d4ed8']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{
                    borderRadius: 20,
                    padding: 24,
                  }}
                >
                  <View className="flex-row items-center">
                    <View className="w-16 h-16 bg-white/20 rounded-full items-center justify-center">
                      <Shield size={32} color="#fff" />
                    </View>
                    <View className="ml-4 flex-1">
                      <Text className="text-white text-2xl font-bold">
                        {t('firstResponder')}
                      </Text>
                      <Text className="text-white/70 text-sm mt-1">
                        {language === 'en'
                          ? 'Help mothers in need'
                          : 'ساعد الأمهات المحتاجات'}
                      </Text>
                    </View>
                  </View>
                </LinearGradient>
              </Pressable>
            </View>
          </View>

          {/* Footer */}
          <View className="pb-8">
            <Text className="text-slate-500 text-center text-xs">
              {language === 'en'
                ? 'Maternal health support in crisis zones'
                : 'دعم صحة الأم في مناطق الأزمات'}
            </Text>
          </View>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}
