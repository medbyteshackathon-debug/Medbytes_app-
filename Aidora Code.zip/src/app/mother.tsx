import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, TextInput, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLanguage } from '@/lib/language-context';
import { useMotherStore, calculatePriority, generateId, MotherForm, Priority } from '@/lib/mother-store';
import { ChevronDown, ChevronUp, LogOut, QrCode, AlertCircle, CheckCircle, AlertTriangle, Info, Pencil, Trash2, Volume2, VolumeX } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import QRCode from 'react-qr-code';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import * as Speech from 'expo-speech';

type Tab = 'form' | 'status' | 'info';

// Expandable Section Component with TTS
function ExpandableSection({
  title,
  isExpanded,
  onToggle,
  children,
  onSpeak,
  currentAnswer,
}: {
  title: string;
  isExpanded: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  onSpeak?: () => void;
  currentAnswer?: string;
}) {
  return (
    <View className="mb-3 bg-slate-800/60 rounded-xl overflow-hidden">
      <View className="flex-row items-center justify-between p-4">
        <Pressable
          onPress={onToggle}
          className="flex-row items-center flex-1 active:opacity-70"
        >
          <Text className="text-white font-semibold text-base flex-1">{title}</Text>
          {currentAnswer && (
            <Text className="text-teal-400 text-sm mr-2" numberOfLines={1}>{currentAnswer}</Text>
          )}
          {isExpanded ? (
            <ChevronUp size={20} color="#94a3b8" />
          ) : (
            <ChevronDown size={20} color="#94a3b8" />
          )}
        </Pressable>
        {onSpeak && (
          <Pressable
            onPress={onSpeak}
            className="ml-2 p-2 bg-slate-700/50 rounded-lg active:bg-slate-600"
          >
            <Volume2 size={18} color="#14b8a6" />
          </Pressable>
        )}
      </View>
      {isExpanded && (
        <Animated.View entering={FadeIn.duration(200)} exiting={FadeOut.duration(150)}>
          <View className="px-4 pb-4 border-t border-slate-700/50">
            {children}
          </View>
        </Animated.View>
      )}
    </View>
  );
}

// Selection Option Component
function SelectOption({
  label,
  isSelected,
  onSelect,
}: {
  label: string;
  isSelected: boolean;
  onSelect: () => void;
}) {
  return (
    <Pressable
      onPress={onSelect}
      className={`py-2 px-3 rounded-lg mr-2 mb-2 ${
        isSelected ? 'bg-teal-500' : 'bg-slate-700/50'
      }`}
    >
      <Text className={`text-sm ${isSelected ? 'text-white font-medium' : 'text-slate-300'}`}>
        {label}
      </Text>
    </Pressable>
  );
}

// Toggle Component
function Toggle({
  value,
  onToggle,
  yesLabel,
  noLabel,
}: {
  value: boolean;
  onToggle: (val: boolean) => void;
  yesLabel: string;
  noLabel: string;
}) {
  return (
    <View className="flex-row mt-2">
      <Pressable
        onPress={() => onToggle(true)}
        className={`py-2 px-4 rounded-l-lg ${value ? 'bg-teal-500' : 'bg-slate-700/50'}`}
      >
        <Text className={`text-sm ${value ? 'text-white font-medium' : 'text-slate-300'}`}>
          {yesLabel}
        </Text>
      </Pressable>
      <Pressable
        onPress={() => onToggle(false)}
        className={`py-2 px-4 rounded-r-lg ${!value ? 'bg-rose-500' : 'bg-slate-700/50'}`}
      >
        <Text className={`text-sm ${!value ? 'text-white font-medium' : 'text-slate-300'}`}>
          {noLabel}
        </Text>
      </Pressable>
    </View>
  );
}

// Symptom Selector Component
function SymptomSelector({
  label,
  value,
  onSelect,
  options,
  isExpanded,
  onToggleExpand,
}: {
  label: string;
  value?: string;
  onSelect: (val: string | undefined) => void;
  options: { key: string; label: string }[];
  isExpanded: boolean;
  onToggleExpand: () => void;
}) {
  return (
    <View className="mb-3">
      <Pressable
        onPress={onToggleExpand}
        className="flex-row items-center justify-between py-2"
      >
        <View className="flex-row items-center flex-1">
          <Text className="text-slate-300 text-sm">{label}</Text>
          {value && (
            <View className="ml-2 bg-teal-500/20 px-2 py-0.5 rounded">
              <Text className="text-teal-400 text-xs">{options.find(o => o.key === value)?.label}</Text>
            </View>
          )}
        </View>
        {isExpanded ? (
          <ChevronUp size={16} color="#64748b" />
        ) : (
          <ChevronDown size={16} color="#64748b" />
        )}
      </Pressable>
      {isExpanded && (
        <View className="flex-row flex-wrap mt-2">
          {options.map((option) => (
            <SelectOption
              key={option.key}
              label={option.label}
              isSelected={value === option.key}
              onSelect={() => onSelect(value === option.key ? undefined : option.key)}
            />
          ))}
        </View>
      )}
    </View>
  );
}

// Health Condition Toggle Component
function ConditionToggle({
  label,
  value,
  onToggle,
}: {
  label: string;
  value: boolean;
  onToggle: (val: boolean) => void;
}) {
  return (
    <Pressable
      onPress={() => onToggle(!value)}
      className={`py-2 px-3 rounded-lg mr-2 mb-2 ${
        value ? 'bg-rose-500' : 'bg-slate-700/50'
      }`}
    >
      <Text className={`text-sm ${value ? 'text-white font-medium' : 'text-slate-300'}`}>
        {label}
      </Text>
    </Pressable>
  );
}

// Priority Badge Component
function PriorityBadge({ priority }: { priority: Priority }) {
  const colors = {
    critical: { bg: 'bg-red-500', text: 'Critical' },
    high: { bg: 'bg-orange-500', text: 'High' },
    medium: { bg: 'bg-yellow-500', text: 'Medium' },
    low: { bg: 'bg-green-500', text: 'Low' },
  };

  return (
    <View className={`px-3 py-1 rounded-full ${colors[priority].bg}`}>
      <Text className="text-white font-bold text-xs uppercase">{colors[priority].text}</Text>
    </View>
  );
}

// Mother Card Component with Edit/Delete
function MotherCard({
  mother,
  isExpanded,
  onToggle,
  onEdit,
  onDelete,
  t,
  language,
}: {
  mother: MotherForm;
  isExpanded: boolean;
  onToggle: () => void;
  onEdit: (mother: MotherForm) => void;
  onDelete: (id: string) => void;
  t: (key: string) => string;
  language: string;
}) {
  const [showQR, setShowQR] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const priorityColors = {
    critical: 'border-red-500',
    high: 'border-orange-500',
    medium: 'border-yellow-500',
    low: 'border-green-500',
  };

  const qrData = JSON.stringify({
    ...mother,
    transferType: 'aidora-mother-form',
  });

  const handleDelete = () => {
    Alert.alert(
      language === 'en' ? 'Delete Form' : 'حذف النموذج',
      language === 'en' ? `Are you sure you want to delete ${mother.name}'s form?` : `هل أنت متأكد من حذف نموذج ${mother.name}؟`,
      [
        { text: language === 'en' ? 'Cancel' : 'إلغاء', style: 'cancel' },
        { text: language === 'en' ? 'Delete' : 'حذف', style: 'destructive', onPress: () => onDelete(mother.id) },
      ]
    );
  };

  const generateSpeechText = () => {
    const priorityText = {
      critical: language === 'en' ? 'Critical' : 'حرج',
      high: language === 'en' ? 'High' : 'عالي',
      medium: language === 'en' ? 'Medium' : 'متوسط',
      low: language === 'en' ? 'Low' : 'منخفض',
    };

    const symptoms: string[] = [];
    if (mother.symptoms.bleeding) symptoms.push(t('bleeding'));
    if (mother.symptoms.headache) symptoms.push(t('headache'));
    if (mother.symptoms.swelling) symptoms.push(t('swelling'));
    if (mother.symptoms.dizziness) symptoms.push(t('dizziness'));
    if (mother.symptoms.cramping) symptoms.push(t('cramping'));
    if (mother.symptoms.fever) symptoms.push(t('fever'));
    if (mother.symptoms.fetalMovement) symptoms.push(t('fetalMovement'));

    const conditions: string[] = [];
    if (mother.healthConditions.diabetes) conditions.push(t('diabetes'));
    if (mother.healthConditions.cancer) conditions.push(t('cancer'));
    if (mother.healthConditions.kidney) conditions.push(t('kidney'));
    if (mother.healthConditions.anemia) conditions.push(t('anemia'));
    if (mother.healthConditions.covid) conditions.push(t('covid'));
    if (mother.healthConditions.heartDisease) conditions.push(t('heartDisease'));

    if (language === 'en') {
      let text = `Patient ${mother.name}. ID: ${mother.id}. Priority level: ${priorityText[mother.priority]}. `;
      text += `Age group: ${t(mother.age)}. ${t(mother.trimester)}. `;
      text += `${mother.firstBaby ? 'First pregnancy' : 'Not first pregnancy'}. `;
      text += `Number of babies: ${t(mother.numberOfBabies)}. `;
      if (symptoms.length > 0) text += `Symptoms include: ${symptoms.join(', ')}. `;
      if (conditions.length > 0) text += `Health conditions: ${conditions.join(', ')}. `;
      if (mother.additionalInfo) text += `Additional notes: ${mother.additionalInfo}`;
      return text;
    } else {
      let text = `المريضة ${mother.name}. رقم التعريف: ${mother.id}. مستوى الأولوية: ${priorityText[mother.priority]}. `;
      text += `الفئة العمرية: ${t(mother.age)}. ${t(mother.trimester)}. `;
      text += `${mother.firstBaby ? 'الحمل الأول' : 'ليس الحمل الأول'}. `;
      text += `عدد الأطفال: ${t(mother.numberOfBabies)}. `;
      if (symptoms.length > 0) text += `الأعراض تشمل: ${symptoms.join('، ')}. `;
      if (conditions.length > 0) text += `الحالات الصحية: ${conditions.join('، ')}. `;
      if (mother.additionalInfo) text += `ملاحظات إضافية: ${mother.additionalInfo}`;
      return text;
    }
  };

  const handleTextToSpeech = async () => {
    if (isSpeaking) {
      Speech.stop();
      setIsSpeaking(false);
    } else {
      const text = generateSpeechText();
      setIsSpeaking(true);
      Speech.speak(text, {
        language: language === 'en' ? 'en-US' : 'ar-SA',
        onDone: () => setIsSpeaking(false),
        onError: () => setIsSpeaking(false),
      });
    }
  };

  return (
    <View className={`mb-3 bg-slate-800/60 rounded-xl overflow-hidden border-l-4 ${priorityColors[mother.priority]}`}>
      <Pressable
        onPress={onToggle}
        className="flex-row items-center justify-between p-4 active:bg-slate-700/50"
      >
        <View className="flex-row items-center flex-1">
          <Text className="text-white font-semibold text-base">{mother.id}</Text>
          <Text className="text-slate-400 text-sm ml-2">- {mother.name}</Text>
        </View>
        <View className="flex-row items-center">
          <PriorityBadge priority={mother.priority} />
          {isExpanded ? (
            <ChevronUp size={20} color="#94a3b8" style={{ marginLeft: 8 }} />
          ) : (
            <ChevronDown size={20} color="#94a3b8" style={{ marginLeft: 8 }} />
          )}
        </View>
      </Pressable>
      {isExpanded && (
        <Animated.View entering={FadeIn.duration(200)} exiting={FadeOut.duration(150)}>
          <View className="px-4 pb-4 border-t border-slate-700/50">
            {/* Action Buttons */}
            <View className="flex-row justify-end pt-3 gap-2">
              <Pressable
                onPress={handleTextToSpeech}
                className={`p-2 rounded-lg ${isSpeaking ? 'bg-teal-500' : 'bg-slate-700'}`}
              >
                {isSpeaking ? (
                  <VolumeX size={18} color="#fff" />
                ) : (
                  <Volume2 size={18} color="#94a3b8" />
                )}
              </Pressable>
              <Pressable
                onPress={() => onEdit(mother)}
                className="p-2 bg-blue-500/20 rounded-lg"
              >
                <Pencil size={18} color="#3b82f6" />
              </Pressable>
              <Pressable
                onPress={handleDelete}
                className="p-2 bg-red-500/20 rounded-lg"
              >
                <Trash2 size={18} color="#ef4444" />
              </Pressable>
            </View>

            <View className="pt-3">
              <Text className="text-slate-400 text-xs">
                {t('submittedAt')}: {new Date(mother.timestamp).toLocaleString()}
              </Text>

              <View className="mt-3">
                <Text className="text-slate-300 text-sm font-medium mb-1">{t('age')}:</Text>
                <Text className="text-white text-sm">{t(mother.age)}</Text>
              </View>

              <View className="mt-2">
                <Text className="text-slate-300 text-sm font-medium mb-1">{t('trimester')}:</Text>
                <Text className="text-white text-sm">{t(mother.trimester)}</Text>
              </View>

              <View className="mt-2">
                <Text className="text-slate-300 text-sm font-medium mb-1">{t('firstBaby')}:</Text>
                <Text className="text-white text-sm">{mother.firstBaby ? t('yes') : t('no')}</Text>
              </View>

              <View className="mt-2">
                <Text className="text-slate-300 text-sm font-medium mb-1">{t('numberOfBabies')}:</Text>
                <Text className="text-white text-sm">{t(mother.numberOfBabies)}</Text>
              </View>

              {/* Symptoms */}
              {Object.entries(mother.symptoms).some(([_, v]) => v) && (
                <View className="mt-3">
                  <Text className="text-slate-300 text-sm font-medium mb-2">{t('commonSymptoms')}:</Text>
                  <View className="flex-row flex-wrap">
                    {mother.symptoms.bleeding && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('bleeding')}: {t(mother.symptoms.bleeding)}</Text>
                      </View>
                    )}
                    {mother.symptoms.headache && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('headache')}: {t(mother.symptoms.headache)}</Text>
                      </View>
                    )}
                    {mother.symptoms.swelling && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('swelling')}: {t(mother.symptoms.swelling)}</Text>
                      </View>
                    )}
                    {mother.symptoms.dizziness && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('dizziness')}: {t(mother.symptoms.dizziness)}</Text>
                      </View>
                    )}
                    {mother.symptoms.cramping && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('cramping')}: {t(mother.symptoms.cramping)}</Text>
                      </View>
                    )}
                    {mother.symptoms.fever && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('fever')}: {t(mother.symptoms.fever)}</Text>
                      </View>
                    )}
                    {mother.symptoms.fetalMovement && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('fetalMovement')}: {t(mother.symptoms.fetalMovement)}</Text>
                      </View>
                    )}
                  </View>
                </View>
              )}

              {/* Health Conditions */}
              {Object.entries(mother.healthConditions).some(([_, v]) => v) && (
                <View className="mt-3">
                  <Text className="text-slate-300 text-sm font-medium mb-2">{t('healthConditions')}:</Text>
                  <View className="flex-row flex-wrap">
                    {mother.healthConditions.diabetes && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('diabetes')}</Text>
                      </View>
                    )}
                    {mother.healthConditions.cancer && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('cancer')}</Text>
                      </View>
                    )}
                    {mother.healthConditions.kidney && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('kidney')}</Text>
                      </View>
                    )}
                    {mother.healthConditions.anemia && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('anemia')}</Text>
                      </View>
                    )}
                    {mother.healthConditions.covid && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('covid')}</Text>
                      </View>
                    )}
                    {mother.healthConditions.heartDisease && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('heartDisease')}</Text>
                      </View>
                    )}
                  </View>
                </View>
              )}

              {/* Location Conditions */}
              {Object.entries(mother.locationConditions).some(([_, v]) => v) && (
                <View className="mt-3">
                  <Text className="text-slate-300 text-sm font-medium mb-2">{t('locationConditions')}:</Text>
                  <View className="flex-row flex-wrap">
                    {mother.locationConditions.displaced && (
                      <View className="bg-blue-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-blue-400 text-xs">{t('displaced')}</Text>
                      </View>
                    )}
                    {mother.locationConditions.foodShortage && (
                      <View className="bg-blue-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-blue-400 text-xs">{t('foodShortage')}</Text>
                      </View>
                    )}
                    {mother.locationConditions.exposureToBombing && (
                      <View className="bg-blue-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-blue-400 text-xs">{t('exposureToBombing')}</Text>
                      </View>
                    )}
                    {mother.locationConditions.ongoingPregnancyCare && (
                      <View className="bg-green-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-green-400 text-xs">{t('ongoingPregnancyCare')}</Text>
                      </View>
                    )}
                    {mother.locationConditions.diseaseOutbreak && (
                      <View className="bg-blue-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-blue-400 text-xs">{t('diseaseOutbreak')}</Text>
                      </View>
                    )}
                  </View>
                </View>
              )}

              {/* Additional Info */}
              {mother.additionalInfo && (
                <View className="mt-3">
                  <Text className="text-slate-300 text-sm font-medium mb-1">{t('additionalInfo')}:</Text>
                  <Text className="text-white text-sm">{mother.additionalInfo}</Text>
                </View>
              )}

              {/* QR Code Button */}
              <Pressable
                onPress={() => setShowQR(!showQR)}
                className="mt-4 bg-teal-500 py-3 rounded-xl flex-row items-center justify-center"
              >
                <QrCode size={20} color="#fff" />
                <Text className="text-white font-semibold ml-2">{t('viewQRCode')}</Text>
              </Pressable>

              {/* QR Code Display */}
              {showQR && (
                <View className="mt-4 bg-white p-4 rounded-xl items-center">
                  <QRCode value={qrData} size={200} />
                  <Text className="text-slate-600 text-xs mt-2 text-center">
                    {mother.id}
                  </Text>
                </View>
              )}
            </View>
          </View>
        </Animated.View>
      )}
    </View>
  );
}

// Form Section Component
function FormSection({
  t,
  language,
  editingMother,
  onCancelEdit,
  onSaveEdit,
}: {
  t: (key: string) => string;
  language: string;
  editingMother: MotherForm | null;
  onCancelEdit: () => void;
  onSaveEdit: () => void;
}) {
  const addMother = useMotherStore((s) => s.addMother);
  const updateMother = useMotherStore((s) => s.updateMother);

  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});
  const [expandedSymptoms, setExpandedSymptoms] = useState<Record<string, boolean>>({});

  // Form state
  const [name, setName] = useState(editingMother?.name ?? '');
  const [age, setAge] = useState(editingMother?.age ?? '');
  const [trimester, setTrimester] = useState(editingMother?.trimester ?? '');
  const [firstBaby, setFirstBaby] = useState(editingMother?.firstBaby ?? true);
  const [numberOfBabies, setNumberOfBabies] = useState(editingMother?.numberOfBabies ?? '');
  const [symptoms, setSymptoms] = useState<Record<string, string | undefined>>(editingMother?.symptoms ?? {});
  const [healthConditions, setHealthConditions] = useState(editingMother?.healthConditions ?? {
    diabetes: false,
    cancer: false,
    kidney: false,
    anemia: false,
    covid: false,
    heartDisease: false,
  });
  const [locationConditions, setLocationConditions] = useState(editingMother?.locationConditions ?? {
    displaced: false,
    foodShortage: false,
    exposureToBombing: false,
    ongoingPregnancyCare: false,
    diseaseOutbreak: false,
  });
  const [additionalInfo, setAdditionalInfo] = useState(editingMother?.additionalInfo ?? '');

  // Update form when editing mother changes
  React.useEffect(() => {
    if (editingMother) {
      setName(editingMother.name);
      setAge(editingMother.age);
      setTrimester(editingMother.trimester);
      setFirstBaby(editingMother.firstBaby);
      setNumberOfBabies(editingMother.numberOfBabies);
      setSymptoms(editingMother.symptoms);
      setHealthConditions(editingMother.healthConditions);
      setLocationConditions(editingMother.locationConditions);
      setAdditionalInfo(editingMother.additionalInfo);
    } else {
      resetForm();
    }
  }, [editingMother]);

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const toggleSymptom = (symptom: string) => {
    setExpandedSymptoms((prev) => ({ ...prev, [symptom]: !prev[symptom] }));
  };

  const severityOptions = [
    { key: 'high', label: t('high') },
    { key: 'medium', label: t('medium') },
    { key: 'low', label: t('low') },
  ];

  const dizzinessOptions = [
    { key: 'constant', label: t('constant') },
    { key: 'medium', label: t('medium') },
    { key: 'low', label: t('low') },
  ];

  const fetalOptions = [
    { key: 'none', label: t('none') },
    { key: 'reduced', label: t('reduced') },
    { key: 'normal', label: t('normal') },
    { key: 'excessive', label: t('excessive') },
  ];

  const resetForm = () => {
    setName('');
    setAge('');
    setTrimester('');
    setFirstBaby(true);
    setNumberOfBabies('');
    setSymptoms({});
    setHealthConditions({
      diabetes: false,
      cancer: false,
      kidney: false,
      anemia: false,
      covid: false,
      heartDisease: false,
    });
    setLocationConditions({
      displaced: false,
      foodShortage: false,
      exposureToBombing: false,
      ongoingPregnancyCare: false,
      diseaseOutbreak: false,
    });
    setAdditionalInfo('');
    setExpandedSections({});
    setExpandedSymptoms({});
  };

  // Text-to-speech helper for form questions
  const speakQuestion = (question: string, answer?: string) => {
    Speech.stop();
    let text = question;
    if (answer) {
      text += `. ${language === 'en' ? 'Your answer is' : 'إجابتك هي'}: ${answer}`;
    } else {
      text += `. ${language === 'en' ? 'No answer selected yet' : 'لم يتم اختيار إجابة بعد'}`;
    }
    Speech.speak(text, {
      language: language === 'en' ? 'en-US' : 'ar-SA',
    });
  };

  // Get current answer text for each field
  const getAgeAnswer = () => age ? t(age) : undefined;
  const getTrimesterAnswer = () => trimester ? t(trimester) : undefined;
  const getFirstBabyAnswer = () => firstBaby ? t('yes') : t('no');
  const getNumberOfBabiesAnswer = () => numberOfBabies ? t(numberOfBabies) : undefined;

  const getSymptomsAnswer = () => {
    const activeSymptoms: string[] = [];
    if (symptoms.bleeding) activeSymptoms.push(`${t('bleeding')}: ${t(symptoms.bleeding)}`);
    if (symptoms.headache) activeSymptoms.push(`${t('headache')}: ${t(symptoms.headache)}`);
    if (symptoms.swelling) activeSymptoms.push(`${t('swelling')}: ${t(symptoms.swelling)}`);
    if (symptoms.dizziness) activeSymptoms.push(`${t('dizziness')}: ${t(symptoms.dizziness)}`);
    if (symptoms.cramping) activeSymptoms.push(`${t('cramping')}: ${t(symptoms.cramping)}`);
    if (symptoms.fever) activeSymptoms.push(`${t('fever')}: ${t(symptoms.fever)}`);
    if (symptoms.fetalMovement) activeSymptoms.push(`${t('fetalMovement')}: ${t(symptoms.fetalMovement)}`);
    return activeSymptoms.length > 0 ? activeSymptoms.join(', ') : undefined;
  };

  const getHealthConditionsAnswer = () => {
    const active: string[] = [];
    if (healthConditions.diabetes) active.push(t('diabetes'));
    if (healthConditions.cancer) active.push(t('cancer'));
    if (healthConditions.kidney) active.push(t('kidney'));
    if (healthConditions.anemia) active.push(t('anemia'));
    if (healthConditions.covid) active.push(t('covid'));
    if (healthConditions.heartDisease) active.push(t('heartDisease'));
    return active.length > 0 ? active.join(', ') : undefined;
  };

  const getLocationConditionsAnswer = () => {
    const active: string[] = [];
    if (locationConditions.displaced) active.push(t('displaced'));
    if (locationConditions.foodShortage) active.push(t('foodShortage'));
    if (locationConditions.exposureToBombing) active.push(t('exposureToBombing'));
    if (locationConditions.ongoingPregnancyCare) active.push(t('ongoingPregnancyCare'));
    if (locationConditions.diseaseOutbreak) active.push(t('diseaseOutbreak'));
    return active.length > 0 ? active.join(', ') : undefined;
  };

  const handleSubmit = () => {
    if (!name || !age || !trimester || !numberOfBabies) {
      return;
    }

    const formData = {
      name,
      age,
      trimester,
      firstBaby,
      numberOfBabies,
      symptoms: {
        bleeding: symptoms.bleeding,
        headache: symptoms.headache,
        swelling: symptoms.swelling,
        dizziness: symptoms.dizziness,
        cramping: symptoms.cramping,
        fever: symptoms.fever,
        fetalMovement: symptoms.fetalMovement,
      },
      healthConditions,
      locationConditions,
      additionalInfo,
    };

    const priority = calculatePriority(formData);

    if (editingMother) {
      // Update existing mother
      const updatedMother: MotherForm = {
        ...formData,
        id: editingMother.id,
        timestamp: new Date().toISOString(),
        priority,
      };
      updateMother(editingMother.id, updatedMother);
      onSaveEdit();
    } else {
      // Add new mother
      const id = generateId();
      const timestamp = new Date().toISOString();

      const motherForm: MotherForm = {
        ...formData,
        id,
        timestamp,
        priority,
      };

      addMother(motherForm);
    }

    resetForm();
  };

  const handleCancel = () => {
    resetForm();
    onCancelEdit();
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      className="flex-1"
    >
      <ScrollView className="flex-1 px-4" showsVerticalScrollIndicator={false}>
        <View className="py-4">
          {/* Edit Mode Banner */}
          {editingMother && (
            <View className="mb-4 bg-blue-500/20 p-3 rounded-xl flex-row items-center justify-between">
              <Text className="text-blue-400 font-medium">
                {language === 'en' ? `Editing: ${editingMother.name}` : `تعديل: ${editingMother.name}`}
              </Text>
              <Pressable onPress={handleCancel}>
                <Text className="text-blue-400 font-medium">
                  {language === 'en' ? 'Cancel' : 'إلغاء'}
                </Text>
              </Pressable>
            </View>
          )}

          {/* Name */}
          <ExpandableSection
            title={t('name')}
            isExpanded={expandedSections.name ?? false}
            onToggle={() => toggleSection('name')}
            onSpeak={() => speakQuestion(t('name'), name || undefined)}
            currentAnswer={name || undefined}
          >
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder={t('enterName')}
              placeholderTextColor="#64748b"
              className="bg-slate-700/50 text-white px-4 py-3 rounded-lg mt-2"
            />
          </ExpandableSection>

          {/* Age */}
          <ExpandableSection
            title={t('age')}
            isExpanded={expandedSections.age ?? false}
            onToggle={() => toggleSection('age')}
            onSpeak={() => speakQuestion(t('age'), getAgeAnswer())}
            currentAnswer={getAgeAnswer()}
          >
            <View className="flex-row flex-wrap mt-2">
              <SelectOption label={t('under18')} isSelected={age === 'under18'} onSelect={() => setAge('under18')} />
              <SelectOption label={t('age18to35')} isSelected={age === 'age18to35'} onSelect={() => setAge('age18to35')} />
              <SelectOption label={t('over35')} isSelected={age === 'over35'} onSelect={() => setAge('over35')} />
            </View>
          </ExpandableSection>

          {/* Trimester */}
          <ExpandableSection
            title={t('trimester')}
            isExpanded={expandedSections.trimester ?? false}
            onToggle={() => toggleSection('trimester')}
            onSpeak={() => speakQuestion(t('trimester'), getTrimesterAnswer())}
            currentAnswer={getTrimesterAnswer()}
          >
            <View className="flex-row flex-wrap mt-2">
              <SelectOption label={t('firstTrimester')} isSelected={trimester === 'firstTrimester'} onSelect={() => setTrimester('firstTrimester')} />
              <SelectOption label={t('secondTrimester')} isSelected={trimester === 'secondTrimester'} onSelect={() => setTrimester('secondTrimester')} />
              <SelectOption label={t('thirdTrimester')} isSelected={trimester === 'thirdTrimester'} onSelect={() => setTrimester('thirdTrimester')} />
            </View>
          </ExpandableSection>

          {/* First Baby */}
          <ExpandableSection
            title={t('firstBaby')}
            isExpanded={expandedSections.firstBaby ?? false}
            onToggle={() => toggleSection('firstBaby')}
            onSpeak={() => speakQuestion(t('firstBaby'), getFirstBabyAnswer())}
            currentAnswer={getFirstBabyAnswer()}
          >
            <Toggle
              value={firstBaby}
              onToggle={setFirstBaby}
              yesLabel={t('yes')}
              noLabel={t('no')}
            />
          </ExpandableSection>

          {/* Number of Babies */}
          <ExpandableSection
            title={t('numberOfBabies')}
            isExpanded={expandedSections.numberOfBabies ?? false}
            onToggle={() => toggleSection('numberOfBabies')}
            onSpeak={() => speakQuestion(t('numberOfBabies'), getNumberOfBabiesAnswer())}
            currentAnswer={getNumberOfBabiesAnswer()}
          >
            <View className="flex-row flex-wrap mt-2">
              <SelectOption label={t('oneBaby')} isSelected={numberOfBabies === 'oneBaby'} onSelect={() => setNumberOfBabies('oneBaby')} />
              <SelectOption label={t('twins')} isSelected={numberOfBabies === 'twins'} onSelect={() => setNumberOfBabies('twins')} />
              <SelectOption label={t('triplets')} isSelected={numberOfBabies === 'triplets'} onSelect={() => setNumberOfBabies('triplets')} />
              <SelectOption label={t('moreThan3')} isSelected={numberOfBabies === 'moreThan3'} onSelect={() => setNumberOfBabies('moreThan3')} />
            </View>
          </ExpandableSection>

          {/* Common Symptoms */}
          <ExpandableSection
            title={t('commonSymptoms')}
            isExpanded={expandedSections.symptoms ?? false}
            onToggle={() => toggleSection('symptoms')}
            onSpeak={() => speakQuestion(t('commonSymptoms'), getSymptomsAnswer())}
            currentAnswer={getSymptomsAnswer() ? `${Object.values(symptoms).filter(Boolean).length} selected` : undefined}
          >
            <View className="mt-2">
              <SymptomSelector
                label={t('bleeding')}
                value={symptoms.bleeding}
                onSelect={(val) => setSymptoms((prev) => ({ ...prev, bleeding: val }))}
                options={severityOptions}
                isExpanded={expandedSymptoms.bleeding ?? false}
                onToggleExpand={() => toggleSymptom('bleeding')}
              />
              <SymptomSelector
                label={t('headache')}
                value={symptoms.headache}
                onSelect={(val) => setSymptoms((prev) => ({ ...prev, headache: val }))}
                options={severityOptions}
                isExpanded={expandedSymptoms.headache ?? false}
                onToggleExpand={() => toggleSymptom('headache')}
              />
              <SymptomSelector
                label={t('swelling')}
                value={symptoms.swelling}
                onSelect={(val) => setSymptoms((prev) => ({ ...prev, swelling: val }))}
                options={severityOptions}
                isExpanded={expandedSymptoms.swelling ?? false}
                onToggleExpand={() => toggleSymptom('swelling')}
              />
              <SymptomSelector
                label={t('dizziness')}
                value={symptoms.dizziness}
                onSelect={(val) => setSymptoms((prev) => ({ ...prev, dizziness: val }))}
                options={dizzinessOptions}
                isExpanded={expandedSymptoms.dizziness ?? false}
                onToggleExpand={() => toggleSymptom('dizziness')}
              />
              <SymptomSelector
                label={t('cramping')}
                value={symptoms.cramping}
                onSelect={(val) => setSymptoms((prev) => ({ ...prev, cramping: val }))}
                options={severityOptions}
                isExpanded={expandedSymptoms.cramping ?? false}
                onToggleExpand={() => toggleSymptom('cramping')}
              />
              <SymptomSelector
                label={t('fever')}
                value={symptoms.fever}
                onSelect={(val) => setSymptoms((prev) => ({ ...prev, fever: val }))}
                options={severityOptions}
                isExpanded={expandedSymptoms.fever ?? false}
                onToggleExpand={() => toggleSymptom('fever')}
              />
              <SymptomSelector
                label={t('fetalMovement')}
                value={symptoms.fetalMovement}
                onSelect={(val) => setSymptoms((prev) => ({ ...prev, fetalMovement: val }))}
                options={fetalOptions}
                isExpanded={expandedSymptoms.fetalMovement ?? false}
                onToggleExpand={() => toggleSymptom('fetalMovement')}
              />
            </View>
          </ExpandableSection>

          {/* Health Conditions */}
          <ExpandableSection
            title={t('healthConditions')}
            isExpanded={expandedSections.healthConditions ?? false}
            onToggle={() => toggleSection('healthConditions')}
            onSpeak={() => speakQuestion(t('healthConditions'), getHealthConditionsAnswer())}
            currentAnswer={getHealthConditionsAnswer() ? `${Object.values(healthConditions).filter(Boolean).length} selected` : undefined}
          >
            <View className="flex-row flex-wrap mt-2">
              <ConditionToggle
                label={t('diabetes')}
                value={healthConditions.diabetes}
                onToggle={(val) => setHealthConditions((prev) => ({ ...prev, diabetes: val }))}
              />
              <ConditionToggle
                label={t('cancer')}
                value={healthConditions.cancer}
                onToggle={(val) => setHealthConditions((prev) => ({ ...prev, cancer: val }))}
              />
              <ConditionToggle
                label={t('kidney')}
                value={healthConditions.kidney}
                onToggle={(val) => setHealthConditions((prev) => ({ ...prev, kidney: val }))}
              />
              <ConditionToggle
                label={t('anemia')}
                value={healthConditions.anemia}
                onToggle={(val) => setHealthConditions((prev) => ({ ...prev, anemia: val }))}
              />
              <ConditionToggle
                label={t('covid')}
                value={healthConditions.covid}
                onToggle={(val) => setHealthConditions((prev) => ({ ...prev, covid: val }))}
              />
              <ConditionToggle
                label={t('heartDisease')}
                value={healthConditions.heartDisease}
                onToggle={(val) => setHealthConditions((prev) => ({ ...prev, heartDisease: val }))}
              />
            </View>
          </ExpandableSection>

          {/* Location Conditions */}
          <ExpandableSection
            title={t('locationConditions')}
            isExpanded={expandedSections.locationConditions ?? false}
            onToggle={() => toggleSection('locationConditions')}
            onSpeak={() => speakQuestion(t('locationConditions'), getLocationConditionsAnswer())}
            currentAnswer={getLocationConditionsAnswer() ? `${Object.values(locationConditions).filter(Boolean).length} selected` : undefined}
          >
            <View className="mt-2 gap-3">
              <View className="flex-row items-center justify-between">
                <Text className="text-slate-300 text-sm">{t('displaced')}</Text>
                <Toggle
                  value={locationConditions.displaced}
                  onToggle={(val) => setLocationConditions((prev) => ({ ...prev, displaced: val }))}
                  yesLabel={t('yes')}
                  noLabel={t('no')}
                />
              </View>
              <View className="flex-row items-center justify-between">
                <Text className="text-slate-300 text-sm">{t('foodShortage')}</Text>
                <Toggle
                  value={locationConditions.foodShortage}
                  onToggle={(val) => setLocationConditions((prev) => ({ ...prev, foodShortage: val }))}
                  yesLabel={t('yes')}
                  noLabel={t('no')}
                />
              </View>
              <View className="flex-row items-center justify-between">
                <Text className="text-slate-300 text-sm">{t('exposureToBombing')}</Text>
                <Toggle
                  value={locationConditions.exposureToBombing}
                  onToggle={(val) => setLocationConditions((prev) => ({ ...prev, exposureToBombing: val }))}
                  yesLabel={t('yes')}
                  noLabel={t('no')}
                />
              </View>
              <View className="flex-row items-center justify-between">
                <Text className="text-slate-300 text-sm">{t('ongoingPregnancyCare')}</Text>
                <Toggle
                  value={locationConditions.ongoingPregnancyCare}
                  onToggle={(val) => setLocationConditions((prev) => ({ ...prev, ongoingPregnancyCare: val }))}
                  yesLabel={t('yes')}
                  noLabel={t('no')}
                />
              </View>
              <View className="flex-row items-center justify-between">
                <Text className="text-slate-300 text-sm">{t('diseaseOutbreak')}</Text>
                <Toggle
                  value={locationConditions.diseaseOutbreak}
                  onToggle={(val) => setLocationConditions((prev) => ({ ...prev, diseaseOutbreak: val }))}
                  yesLabel={t('yes')}
                  noLabel={t('no')}
                />
              </View>
            </View>
          </ExpandableSection>

          {/* Additional Information */}
          <ExpandableSection
            title={t('additionalInfo')}
            isExpanded={expandedSections.additionalInfo ?? false}
            onToggle={() => toggleSection('additionalInfo')}
            onSpeak={() => speakQuestion(t('additionalInfo'), additionalInfo || undefined)}
            currentAnswer={additionalInfo ? (additionalInfo.length > 20 ? additionalInfo.substring(0, 20) + '...' : additionalInfo) : undefined}
          >
            <TextInput
              value={additionalInfo}
              onChangeText={setAdditionalInfo}
              placeholder={t('extraDetails')}
              placeholderTextColor="#64748b"
              multiline
              numberOfLines={4}
              textAlignVertical="top"
              className="bg-slate-700/50 text-white px-4 py-3 rounded-lg mt-2 min-h-[100px]"
            />
          </ExpandableSection>

          {/* Submit/Update Button */}
          <Pressable
            onPress={handleSubmit}
            disabled={!name || !age || !trimester || !numberOfBabies}
            className={`mt-4 py-4 rounded-xl items-center ${
              name && age && trimester && numberOfBabies ? (editingMother ? 'bg-blue-500' : 'bg-teal-500') : 'bg-slate-600'
            }`}
          >
            <Text className="text-white font-bold text-lg">
              {editingMother
                ? (language === 'en' ? 'Update Form' : 'تحديث النموذج')
                : t('submitForm')
              }
            </Text>
          </Pressable>

          <View className="h-8" />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// Status Section Component
function StatusSection({
  t,
  language,
  onEditMother,
}: {
  t: (key: string) => string;
  language: string;
  onEditMother: (mother: MotherForm) => void;
}) {
  const mothers = useMotherStore((s) => s.mothers);
  const deleteMother = useMotherStore((s) => s.deleteMother);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (mothers.length === 0) {
    return (
      <View className="flex-1 items-center justify-center px-6">
        <View className="w-20 h-20 bg-slate-700/50 rounded-full items-center justify-center mb-4">
          <AlertCircle size={40} color="#64748b" />
        </View>
        <Text className="text-white text-lg font-semibold text-center">
          {t('noFormsSubmitted')}
        </Text>
        <Text className="text-slate-400 text-sm text-center mt-2">
          {t('fillFormFirst')}
        </Text>
      </View>
    );
  }

  return (
    <ScrollView className="flex-1 px-4" showsVerticalScrollIndicator={false}>
      <View className="py-4">
        {mothers.map((mother) => (
          <MotherCard
            key={mother.id}
            mother={mother}
            isExpanded={expandedId === mother.id}
            onToggle={() => setExpandedId(expandedId === mother.id ? null : mother.id)}
            onEdit={onEditMother}
            onDelete={deleteMother}
            t={t}
            language={language}
          />
        ))}
      </View>
    </ScrollView>
  );
}

// Info Section Component
function InfoSection({ t, language }: { t: (key: string) => string; language: string }) {
  const router = useRouter();
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => ({ ...prev, [section]: !prev[section] }));
  };

  const priorityInfo = [
    {
      key: 'critical',
      label: t('critical'),
      color: 'bg-red-500',
      icon: AlertCircle,
      description: t('criticalDesc'),
    },
    {
      key: 'high',
      label: t('priorityHigh'),
      color: 'bg-orange-500',
      icon: AlertTriangle,
      description: t('highDesc'),
    },
    {
      key: 'medium',
      label: t('priorityMedium'),
      color: 'bg-yellow-500',
      icon: Info,
      description: t('mediumDesc'),
    },
    {
      key: 'low',
      label: t('priorityLow'),
      color: 'bg-green-500',
      icon: CheckCircle,
      description: t('lowDesc'),
    },
  ];

  const symptomDefinitions = language === 'en' ? [
    { term: 'Bleeding', definition: 'Any vaginal blood loss during pregnancy. Can range from light spotting to heavy flow.' },
    { term: 'Headache', definition: 'Persistent head pain that may indicate high blood pressure or preeclampsia if severe.' },
    { term: 'Swelling', definition: 'Abnormal fluid retention causing puffiness in hands, feet, or face.' },
    { term: 'Dizziness/Vomiting', definition: 'Feeling faint or nauseous. Constant symptoms may indicate hyperemesis gravidarum.' },
    { term: 'Cramping', definition: 'Abdominal pain or tightening. Severe cramping may indicate preterm labor.' },
    { term: 'Fever', definition: 'Elevated body temperature above 38°C (100.4°F). May indicate infection.' },
    { term: 'Fetal Movement', definition: 'Baby\'s kicks and movements. Reduced or absent movement requires immediate attention.' },
  ] : [
    { term: 'النزيف', definition: 'أي فقدان للدم المهبلي أثناء الحمل. يمكن أن يتراوح من بقع خفيفة إلى تدفق غزير.' },
    { term: 'الصداع', definition: 'ألم مستمر في الرأس قد يشير إلى ارتفاع ضغط الدم أو تسمم الحمل إذا كان شديداً.' },
    { term: 'التورم', definition: 'احتباس غير طبيعي للسوائل يسبب انتفاخاً في اليدين أو القدمين أو الوجه.' },
    { term: 'الدوخة/القيء', definition: 'الشعور بالإغماء أو الغثيان. قد تشير الأعراض المستمرة إلى القيء المفرط الحملي.' },
    { term: 'التشنجات', definition: 'ألم أو شد في البطن. قد تشير التشنجات الشديدة إلى الولادة المبكرة.' },
    { term: 'الحمى', definition: 'ارتفاع درجة حرارة الجسم فوق 38 درجة مئوية. قد تشير إلى وجود عدوى.' },
    { term: 'حركة الجنين', definition: 'ركلات وحركات الطفل. تتطلب الحركة المنخفضة أو الغائبة اهتماماً فورياً.' },
  ];

  const healthConditionDefinitions = language === 'en' ? [
    { term: 'Diabetes', definition: 'A condition where blood sugar levels are too high, requiring careful monitoring during pregnancy.' },
    { term: 'Cancer', definition: 'Presence of malignant cells. Cancer treatment during pregnancy requires specialized care.' },
    { term: 'Kidney Disease', definition: 'Impaired kidney function that can affect blood pressure and waste removal.' },
    { term: 'Anemia', definition: 'Low red blood cell count causing fatigue and weakness. Common but treatable in pregnancy.' },
    { term: 'Covid-19', definition: 'Viral respiratory infection. Pregnant women are at higher risk of severe illness.' },
    { term: 'Heart Disease', definition: 'Conditions affecting the heart\'s ability to pump blood effectively.' },
  ] : [
    { term: 'السكري', definition: 'حالة تكون فيها مستويات السكر في الدم مرتفعة للغاية، وتتطلب مراقبة دقيقة أثناء الحمل.' },
    { term: 'السرطان', definition: 'وجود خلايا خبيثة. يتطلب علاج السرطان أثناء الحمل رعاية متخصصة.' },
    { term: 'أمراض الكلى', definition: 'ضعف وظائف الكلى الذي يمكن أن يؤثر على ضغط الدم وإزالة النفايات.' },
    { term: 'فقر الدم', definition: 'انخفاض عدد خلايا الدم الحمراء مما يسبب التعب والضعف. شائع ولكن قابل للعلاج في الحمل.' },
    { term: 'كوفيد-19', definition: 'عدوى فيروسية تنفسية. النساء الحوامل أكثر عرضة للإصابة الشديدة.' },
    { term: 'أمراض القلب', definition: 'حالات تؤثر على قدرة القلب على ضخ الدم بفعالية.' },
  ];

  const locationConditionDefinitions = language === 'en' ? [
    { term: 'Displaced', definition: 'Forced to leave home due to conflict, disaster, or violence.' },
    { term: 'Food Shortage', definition: 'Limited access to adequate nutrition, critical for maternal and fetal health.' },
    { term: 'Exposure to Bombing', definition: 'Living in or near active conflict zones with risk of explosive harm.' },
    { term: 'Ongoing Pregnancy Care', definition: 'Access to regular prenatal checkups and medical monitoring.' },
    { term: 'Disease Outbreak', definition: 'Presence of epidemic diseases in the area increasing infection risk.' },
  ] : [
    { term: 'نازح', definition: 'مجبر على مغادرة المنزل بسبب الصراع أو الكارثة أو العنف.' },
    { term: 'نقص الغذاء', definition: 'محدودية الوصول إلى التغذية الكافية، وهي ضرورية لصحة الأم والجنين.' },
    { term: 'التعرض للقصف', definition: 'العيش في مناطق نزاع نشطة أو بالقرب منها مع خطر الأضرار المتفجرة.' },
    { term: 'رعاية الحمل المستمرة', definition: 'الوصول إلى فحوصات ما قبل الولادة المنتظمة والمراقبة الطبية.' },
    { term: 'تفشي المرض', definition: 'وجود أمراض وبائية في المنطقة تزيد من خطر العدوى.' },
  ];

  const trimesterDefinitions = language === 'en' ? [
    { term: 'First Trimester (Weeks 1-12)', definition: 'Early pregnancy where major organs begin forming. Higher risk of miscarriage.' },
    { term: 'Second Trimester (Weeks 13-26)', definition: 'Middle pregnancy often considered the most comfortable period. Baby grows significantly.' },
    { term: 'Third Trimester (Weeks 27-40)', definition: 'Final stage of pregnancy. Baby gains weight and prepares for birth. Higher risk of preterm labor.' },
  ] : [
    { term: 'الثلث الأول (الأسابيع 1-12)', definition: 'الحمل المبكر حيث تبدأ الأعضاء الرئيسية بالتشكل. خطر أعلى للإجهاض.' },
    { term: 'الثلث الثاني (الأسابيع 13-26)', definition: 'منتصف الحمل يعتبر غالباً الفترة الأكثر راحة. ينمو الطفل بشكل ملحوظ.' },
    { term: 'الثلث الثالث (الأسابيع 27-40)', definition: 'المرحلة النهائية من الحمل. يزداد وزن الطفل ويستعد للولادة. خطر أعلى للولادة المبكرة.' },
  ];

  return (
    <ScrollView className="flex-1 px-4" showsVerticalScrollIndicator={false}>
      <View className="py-4">
        {/* Priority Explanations */}
        <Text className="text-white text-xl font-bold mb-4">{t('priorityExplanations')}</Text>
        {priorityInfo.map((priority) => (
          <View key={priority.key} className="mb-3 bg-slate-800/60 rounded-xl p-4">
            <View className="flex-row items-center mb-2">
              <View className={`w-10 h-10 ${priority.color} rounded-full items-center justify-center`}>
                <priority.icon size={20} color="#fff" />
              </View>
              <Text className="text-white font-semibold text-lg ml-3">{priority.label}</Text>
            </View>
            <Text className="text-slate-300 text-sm">{priority.description}</Text>
          </View>
        ))}

        {/* Symptom Definitions */}
        <ExpandableSection
          title={t('symptomDefinitions')}
          isExpanded={expandedSections.symptoms ?? false}
          onToggle={() => toggleSection('symptoms')}
        >
          {symptomDefinitions.map((item, index) => (
            <View key={index} className="mt-3">
              <Text className="text-teal-400 font-medium">{item.term}</Text>
              <Text className="text-slate-300 text-sm mt-1">{item.definition}</Text>
            </View>
          ))}
        </ExpandableSection>

        {/* Health Condition Definitions */}
        <ExpandableSection
          title={t('healthConditionDefinitions')}
          isExpanded={expandedSections.healthConditions ?? false}
          onToggle={() => toggleSection('healthConditions')}
        >
          {healthConditionDefinitions.map((item, index) => (
            <View key={index} className="mt-3">
              <Text className="text-amber-400 font-medium">{item.term}</Text>
              <Text className="text-slate-300 text-sm mt-1">{item.definition}</Text>
            </View>
          ))}
        </ExpandableSection>

        {/* Location Condition Definitions */}
        <ExpandableSection
          title={t('locationConditionDefinitions')}
          isExpanded={expandedSections.locationConditions ?? false}
          onToggle={() => toggleSection('locationConditions')}
        >
          {locationConditionDefinitions.map((item, index) => (
            <View key={index} className="mt-3">
              <Text className="text-blue-400 font-medium">{item.term}</Text>
              <Text className="text-slate-300 text-sm mt-1">{item.definition}</Text>
            </View>
          ))}
        </ExpandableSection>

        {/* Trimester Definitions */}
        <ExpandableSection
          title={t('trimesterDefinitions')}
          isExpanded={expandedSections.trimesters ?? false}
          onToggle={() => toggleSection('trimesters')}
        >
          {trimesterDefinitions.map((item, index) => (
            <View key={index} className="mt-3">
              <Text className="text-purple-400 font-medium">{item.term}</Text>
              <Text className="text-slate-300 text-sm mt-1">{item.definition}</Text>
            </View>
          ))}
        </ExpandableSection>

        {/* Logout Button */}
        <Pressable
          onPress={() => router.replace('/')}
          className="mt-8 mb-4 bg-slate-700 py-4 rounded-xl flex-row items-center justify-center"
        >
          <LogOut size={20} color="#ef4444" />
          <Text className="text-red-400 font-semibold ml-2">{t('logout')}</Text>
        </Pressable>

        <View className="h-8" />
      </View>
    </ScrollView>
  );
}

export default function MotherScreen() {
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState<Tab>('form');
  const [editingMother, setEditingMother] = useState<MotherForm | null>(null);

  const handleEditMother = (mother: MotherForm) => {
    setEditingMother(mother);
    setActiveTab('form');
  };

  const handleCancelEdit = () => {
    setEditingMother(null);
  };

  const handleSaveEdit = () => {
    setEditingMother(null);
    setActiveTab('status');
  };

  return (
    <View className="flex-1 bg-slate-900">
      <LinearGradient
        colors={['#1e293b', '#0f172a', '#020617']}
        style={{ flex: 1 }}
      >
        <SafeAreaView className="flex-1" edges={['top']}>
          {/* Navigation Pane */}
          <View className="px-4 pt-2 pb-3">
            <View className="flex-row bg-slate-800/80 rounded-xl p-1">
              <Pressable
                onPress={() => setActiveTab('form')}
                className={`flex-1 py-3 rounded-lg items-center ${
                  activeTab === 'form' ? 'bg-teal-500' : ''
                }`}
              >
                <Text
                  className={`text-sm font-medium ${
                    activeTab === 'form' ? 'text-white' : 'text-slate-400'
                  }`}
                >
                  {t('form')}
                </Text>
              </Pressable>
              <Pressable
                onPress={() => setActiveTab('status')}
                className={`flex-1 py-3 rounded-lg items-center ${
                  activeTab === 'status' ? 'bg-teal-500' : ''
                }`}
              >
                <Text
                  className={`text-sm font-medium ${
                    activeTab === 'status' ? 'text-white' : 'text-slate-400'
                  }`}
                >
                  {t('yourStatus')}
                </Text>
              </Pressable>
              <Pressable
                onPress={() => setActiveTab('info')}
                className={`flex-1 py-3 rounded-lg items-center ${
                  activeTab === 'info' ? 'bg-teal-500' : ''
                }`}
              >
                <Text
                  className={`text-sm font-medium ${
                    activeTab === 'info' ? 'text-white' : 'text-slate-400'
                  }`}
                >
                  {t('information')}
                </Text>
              </Pressable>
            </View>
          </View>

          {/* Content */}
          {activeTab === 'form' && (
            <FormSection
              t={t}
              language={language}
              editingMother={editingMother}
              onCancelEdit={handleCancelEdit}
              onSaveEdit={handleSaveEdit}
            />
          )}
          {activeTab === 'status' && (
            <StatusSection
              t={t}
              language={language}
              onEditMother={handleEditMother}
            />
          )}
          {activeTab === 'info' && <InfoSection t={t} language={language} />}
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}
