import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLanguage } from '@/lib/language-context';
import { useResponderStore, ReceivedForm } from '@/lib/responder-store';
import { Priority } from '@/lib/mother-store';
import {
  LayoutDashboard,
  QrCode,
  BarChart3,
  Info,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  AlertTriangle,
  CheckCircle,
  LogOut,
  Camera,
  FileText,
  Check,
  RotateCcw
} from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { CameraView, useCameraPermissions } from 'expo-camera';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';

type Tab = 'dashboard' | 'qrcode' | 'status' | 'info';

// Priority Badge Component
function PriorityBadge({ priority, completed }: { priority: Priority; completed?: boolean }) {
  const colors = {
    critical: { bg: 'bg-red-500', text: 'Critical' },
    high: { bg: 'bg-orange-500', text: 'High' },
    medium: { bg: 'bg-yellow-500', text: 'Medium' },
    low: { bg: 'bg-green-500', text: 'Low' },
  };

  if (completed) {
    return (
      <View className="px-3 py-1 rounded-full bg-slate-500 flex-row items-center">
        <Check size={12} color="#fff" />
        <Text className="text-white font-bold text-xs uppercase ml-1">Completed</Text>
      </View>
    );
  }

  return (
    <View className={`px-3 py-1 rounded-full ${colors[priority].bg}`}>
      <Text className="text-white font-bold text-xs uppercase">{colors[priority].text}</Text>
    </View>
  );
}

// Mother Form Card for Dashboard
function MotherFormCard({
  form,
  isExpanded,
  onToggle,
  onMarkComplete,
  onMarkIncomplete,
  t,
  language,
}: {
  form: ReceivedForm;
  isExpanded: boolean;
  onToggle: () => void;
  onMarkComplete: (id: string) => void;
  onMarkIncomplete: (id: string) => void;
  t: (key: string) => string;
  language: string;
}) {
  const priorityColors = {
    critical: 'border-red-500',
    high: 'border-orange-500',
    medium: 'border-yellow-500',
    low: 'border-green-500',
  };

  const handleToggleComplete = () => {
    if (form.completed) {
      Alert.alert(
        language === 'en' ? 'Reopen Case' : 'إعادة فتح الحالة',
        language === 'en'
          ? `Are you sure you want to reopen ${form.name}'s case?`
          : `هل أنت متأكد من إعادة فتح حالة ${form.name}؟`,
        [
          { text: language === 'en' ? 'Cancel' : 'إلغاء', style: 'cancel' },
          { text: language === 'en' ? 'Reopen' : 'إعادة فتح', onPress: () => onMarkIncomplete(form.id) },
        ]
      );
    } else {
      Alert.alert(
        language === 'en' ? 'Mark as Complete' : 'وضع علامة مكتمل',
        language === 'en'
          ? `Are you sure you want to mark ${form.name}'s case as complete?`
          : `هل أنت متأكد من وضع علامة مكتمل على حالة ${form.name}؟`,
        [
          { text: language === 'en' ? 'Cancel' : 'إلغاء', style: 'cancel' },
          { text: language === 'en' ? 'Complete' : 'إكمال', onPress: () => onMarkComplete(form.id) },
        ]
      );
    }
  };

  return (
    <View className={`mb-3 bg-slate-800/60 rounded-xl overflow-hidden border-l-4 ${form.completed ? 'border-slate-500' : priorityColors[form.priority]} ${form.completed ? 'opacity-70' : ''}`}>
      <Pressable
        onPress={onToggle}
        className="flex-row items-center justify-between p-4 active:bg-slate-700/50"
      >
        <View className="flex-row items-center flex-1">
          <Text className={`font-semibold text-base ${form.completed ? 'text-slate-400 line-through' : 'text-white'}`}>{form.id}</Text>
          <Text className={`text-sm ml-2 ${form.completed ? 'text-slate-500 line-through' : 'text-slate-400'}`}>- {form.name}</Text>
        </View>
        <View className="flex-row items-center">
          <PriorityBadge priority={form.priority} completed={form.completed} />
          {isExpanded ? (
            <ChevronUp size={20} color="#94a3b8" style={{ marginLeft: 8 }} />
          ) : (
            <ChevronDown size={20} color="#94a3b8" style={{ marginLeft: 8 }} />
          )}
        </View>
      </Pressable>
      {isExpanded && (
        <Animated.View entering={FadeIn.duration(200)} exiting={FadeOut.duration(150)}>
          <View className="px-4 pb-4 border-t border-slate-700/50">
            {/* Complete/Reopen Button */}
            <View className="pt-3 flex-row justify-end">
              <Pressable
                onPress={handleToggleComplete}
                className={`px-4 py-2 rounded-lg flex-row items-center ${form.completed ? 'bg-blue-500/20' : 'bg-green-500/20'}`}
              >
                {form.completed ? (
                  <>
                    <RotateCcw size={16} color="#3b82f6" />
                    <Text className="text-blue-400 font-medium ml-2">
                      {language === 'en' ? 'Reopen' : 'إعادة فتح'}
                    </Text>
                  </>
                ) : (
                  <>
                    <Check size={16} color="#22c55e" />
                    <Text className="text-green-400 font-medium ml-2">
                      {language === 'en' ? 'Mark Complete' : 'وضع علامة مكتمل'}
                    </Text>
                  </>
                )}
              </Pressable>
            </View>

            <View className="pt-3">
              <Text className="text-slate-400 text-xs">
                {t('submittedAt')}: {new Date(form.timestamp).toLocaleString()}
              </Text>

              {form.completed && form.completedAt && (
                <Text className="text-green-400 text-xs">
                  {language === 'en' ? 'Completed at' : 'اكتمل في'}: {new Date(form.completedAt).toLocaleString()}
                </Text>
              )}

              <View className="mt-3">
                <Text className="text-slate-300 text-sm font-medium mb-1">{t('age')}:</Text>
                <Text className="text-white text-sm">{t(form.age)}</Text>
              </View>

              <View className="mt-2">
                <Text className="text-slate-300 text-sm font-medium mb-1">{t('trimester')}:</Text>
                <Text className="text-white text-sm">{t(form.trimester)}</Text>
              </View>

              <View className="mt-2">
                <Text className="text-slate-300 text-sm font-medium mb-1">{t('firstBaby')}:</Text>
                <Text className="text-white text-sm">{form.firstBaby ? t('yes') : t('no')}</Text>
              </View>

              <View className="mt-2">
                <Text className="text-slate-300 text-sm font-medium mb-1">{t('numberOfBabies')}:</Text>
                <Text className="text-white text-sm">{t(form.numberOfBabies)}</Text>
              </View>

              {/* Symptoms */}
              {Object.entries(form.symptoms).some(([_, v]) => v) && (
                <View className="mt-3">
                  <Text className="text-slate-300 text-sm font-medium mb-2">{t('commonSymptoms')}:</Text>
                  <View className="flex-row flex-wrap">
                    {form.symptoms.bleeding && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('bleeding')}: {t(form.symptoms.bleeding)}</Text>
                      </View>
                    )}
                    {form.symptoms.headache && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('headache')}: {t(form.symptoms.headache)}</Text>
                      </View>
                    )}
                    {form.symptoms.swelling && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('swelling')}: {t(form.symptoms.swelling)}</Text>
                      </View>
                    )}
                    {form.symptoms.dizziness && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('dizziness')}: {t(form.symptoms.dizziness)}</Text>
                      </View>
                    )}
                    {form.symptoms.cramping && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('cramping')}: {t(form.symptoms.cramping)}</Text>
                      </View>
                    )}
                    {form.symptoms.fever && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('fever')}: {t(form.symptoms.fever)}</Text>
                      </View>
                    )}
                    {form.symptoms.fetalMovement && (
                      <View className="bg-rose-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-rose-400 text-xs">{t('fetalMovement')}: {t(form.symptoms.fetalMovement)}</Text>
                      </View>
                    )}
                  </View>
                </View>
              )}

              {/* Health Conditions */}
              {Object.entries(form.healthConditions).some(([_, v]) => v) && (
                <View className="mt-3">
                  <Text className="text-slate-300 text-sm font-medium mb-2">{t('healthConditions')}:</Text>
                  <View className="flex-row flex-wrap">
                    {form.healthConditions.diabetes && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('diabetes')}</Text>
                      </View>
                    )}
                    {form.healthConditions.cancer && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('cancer')}</Text>
                      </View>
                    )}
                    {form.healthConditions.kidney && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('kidney')}</Text>
                      </View>
                    )}
                    {form.healthConditions.anemia && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('anemia')}</Text>
                      </View>
                    )}
                    {form.healthConditions.covid && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('covid')}</Text>
                      </View>
                    )}
                    {form.healthConditions.heartDisease && (
                      <View className="bg-amber-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-amber-400 text-xs">{t('heartDisease')}</Text>
                      </View>
                    )}
                  </View>
                </View>
              )}

              {/* Location Conditions */}
              {Object.entries(form.locationConditions).some(([_, v]) => v) && (
                <View className="mt-3">
                  <Text className="text-slate-300 text-sm font-medium mb-2">{t('locationConditions')}:</Text>
                  <View className="flex-row flex-wrap">
                    {form.locationConditions.displaced && (
                      <View className="bg-blue-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-blue-400 text-xs">{t('displaced')}</Text>
                      </View>
                    )}
                    {form.locationConditions.foodShortage && (
                      <View className="bg-blue-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-blue-400 text-xs">{t('foodShortage')}</Text>
                      </View>
                    )}
                    {form.locationConditions.exposureToBombing && (
                      <View className="bg-blue-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-blue-400 text-xs">{t('exposureToBombing')}</Text>
                      </View>
                    )}
                    {form.locationConditions.ongoingPregnancyCare && (
                      <View className="bg-green-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-green-400 text-xs">{t('ongoingPregnancyCare')}</Text>
                      </View>
                    )}
                    {form.locationConditions.diseaseOutbreak && (
                      <View className="bg-blue-500/20 px-2 py-1 rounded mr-2 mb-1">
                        <Text className="text-blue-400 text-xs">{t('diseaseOutbreak')}</Text>
                      </View>
                    )}
                  </View>
                </View>
              )}

              {/* Additional Info */}
              {form.additionalInfo && (
                <View className="mt-3">
                  <Text className="text-slate-300 text-sm font-medium mb-1">{t('additionalInfo')}:</Text>
                  <Text className="text-white text-sm">{form.additionalInfo}</Text>
                </View>
              )}
            </View>
          </View>
        </Animated.View>
      )}
    </View>
  );
}

// Dashboard Section
function DashboardSection({ t, language }: { t: (key: string) => string; language: string }) {
  const receivedForms = useResponderStore((s) => s.receivedForms);
  const markAsCompleted = useResponderStore((s) => s.markAsCompleted);
  const markAsIncomplete = useResponderStore((s) => s.markAsIncomplete);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [showCompleted, setShowCompleted] = useState(false);

  // Sort by priority (critical first), then completed at the end
  const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  const sortedForms = [...receivedForms].sort((a, b) => {
    // Completed forms go to the end
    if (a.completed && !b.completed) return 1;
    if (!a.completed && b.completed) return -1;
    // Then sort by priority
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  const activeForms = sortedForms.filter(f => !f.completed);
  const completedForms = sortedForms.filter(f => f.completed);

  if (receivedForms.length === 0) {
    return (
      <View className="flex-1 items-center justify-center px-6">
        <View className="w-20 h-20 bg-slate-700/50 rounded-full items-center justify-center mb-4">
          <FileText size={40} color="#64748b" />
        </View>
        <Text className="text-white text-lg font-semibold text-center">
          {t('noFormsReceived')}
        </Text>
        <Text className="text-slate-400 text-sm text-center mt-2">
          {t('scanQRToReceive')}
        </Text>
      </View>
    );
  }

  return (
    <ScrollView className="flex-1 px-4" showsVerticalScrollIndicator={false}>
      <View className="py-4">
        <Text className="text-white text-xl font-bold mb-4">{t('receivedForms')}</Text>

        {/* Active Cases */}
        {activeForms.map((form) => (
          <MotherFormCard
            key={form.id}
            form={form}
            isExpanded={expandedId === form.id}
            onToggle={() => setExpandedId(expandedId === form.id ? null : form.id)}
            onMarkComplete={markAsCompleted}
            onMarkIncomplete={markAsIncomplete}
            t={t}
            language={language}
          />
        ))}

        {/* Completed Cases Section */}
        {completedForms.length > 0 && (
          <>
            <Pressable
              onPress={() => setShowCompleted(!showCompleted)}
              className="flex-row items-center justify-between py-3 mt-4 mb-2"
            >
              <Text className="text-slate-400 font-medium">
                {language === 'en' ? `Completed Cases (${completedForms.length})` : `الحالات المكتملة (${completedForms.length})`}
              </Text>
              {showCompleted ? (
                <ChevronUp size={20} color="#64748b" />
              ) : (
                <ChevronDown size={20} color="#64748b" />
              )}
            </Pressable>

            {showCompleted && completedForms.map((form) => (
              <MotherFormCard
                key={form.id}
                form={form}
                isExpanded={expandedId === form.id}
                onToggle={() => setExpandedId(expandedId === form.id ? null : form.id)}
                onMarkComplete={markAsCompleted}
                onMarkIncomplete={markAsIncomplete}
                t={t}
                language={language}
              />
            ))}
          </>
        )}
      </View>
    </ScrollView>
  );
}

// QR Scanner Section - Fixed to not use children inside CameraView
function QRScannerSection({ t }: { t: (key: string) => string }) {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const addReceivedForm = useResponderStore((s) => s.addReceivedForm);
  const hasForm = useResponderStore((s) => s.hasForm);

  const handleBarCodeScanned = ({ data }: { data: string }) => {
    if (scanned) return;

    try {
      const parsedData = JSON.parse(data);

      if (parsedData.transferType === 'aidora-mother-form') {
        setScanned(true);

        // Check if form already exists
        if (hasForm(parsedData.id)) {
          Alert.alert(
            'Form Already Exists',
            `Form ${parsedData.id} has already been received.`,
            [{ text: 'OK', onPress: () => setScanned(false) }]
          );
          return;
        }

        // Remove the transferType field before storing
        const { transferType, ...formData } = parsedData;
        addReceivedForm(formData);

        Alert.alert(
          'Form Received',
          `Successfully received form for ${formData.name} (${formData.id}).\nPriority: ${formData.priority.toUpperCase()}`,
          [{ text: 'OK', onPress: () => setScanned(false) }]
        );
      } else {
        setScanned(true);
        Alert.alert(
          'Invalid QR Code',
          'This QR code does not contain valid Aidora form data.',
          [{ text: 'OK', onPress: () => setScanned(false) }]
        );
      }
    } catch {
      setScanned(true);
      Alert.alert(
        'Invalid QR Code',
        'Could not parse QR code data.',
        [{ text: 'OK', onPress: () => setScanned(false) }]
      );
    }
  };

  if (!permission) {
    return (
      <View className="flex-1 items-center justify-center">
        <Text className="text-white">Requesting camera permission...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View className="flex-1 items-center justify-center px-6">
        <View className="w-20 h-20 bg-slate-700/50 rounded-full items-center justify-center mb-4">
          <Camera size={40} color="#64748b" />
        </View>
        <Text className="text-white text-lg font-semibold text-center mb-4">
          Camera Permission Required
        </Text>
        <Pressable
          onPress={requestPermission}
          className="bg-blue-500 px-6 py-3 rounded-xl"
        >
          <Text className="text-white font-semibold">Grant Permission</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View className="flex-1">
      <View className="flex-1 relative overflow-hidden rounded-xl mx-4 my-4">
        <CameraView
          style={{ flex: 1 }}
          barcodeScannerSettings={{
            barcodeTypes: ['qr'],
          }}
          onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
        />
        {/* Overlay positioned absolutely over the camera */}
        <View
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
          pointerEvents="none"
        >
          {/* Scan Frame */}
          <View className="w-64 h-64 border-2 border-white/50 rounded-2xl">
            {/* Corner Decorations */}
            <View className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-blue-500 rounded-tl-lg" />
            <View className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-blue-500 rounded-tr-lg" />
            <View className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-blue-500 rounded-bl-lg" />
            <View className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-blue-500 rounded-br-lg" />
          </View>

          <Text className="text-white text-center mt-6 text-base font-medium">
            {t('pointCamera')}
          </Text>
        </View>
      </View>

      {scanned && (
        <View className="px-4 pb-4">
          <Pressable
            onPress={() => setScanned(false)}
            className="bg-blue-500 py-4 rounded-xl items-center"
          >
            <Text className="text-white font-semibold">Scan Again</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

// Status Summary Section
function StatusSummarySection({ t, language }: { t: (key: string) => string; language: string }) {
  const receivedForms = useResponderStore((s) => s.receivedForms);

  const activeForms = receivedForms.filter(f => !f.completed);
  const completedCount = receivedForms.filter(f => f.completed).length;

  const criticalCount = activeForms.filter((f) => f.priority === 'critical').length;
  const highCount = activeForms.filter((f) => f.priority === 'high').length;
  const mediumCount = activeForms.filter((f) => f.priority === 'medium').length;
  const lowCount = activeForms.filter((f) => f.priority === 'low').length;

  const stats = [
    { label: t('criticalCases'), count: criticalCount, color: 'bg-red-500', icon: AlertCircle },
    { label: t('highCases'), count: highCount, color: 'bg-orange-500', icon: AlertTriangle },
    { label: t('mediumCases'), count: mediumCount, color: 'bg-yellow-500', icon: Info },
    { label: t('lowCases'), count: lowCount, color: 'bg-green-500', icon: CheckCircle },
  ];

  return (
    <ScrollView className="flex-1 px-4" showsVerticalScrollIndicator={false}>
      <View className="py-4">
        <Text className="text-white text-xl font-bold mb-6">{t('statusSummary')}</Text>

        {/* Active Cases */}
        <View className="bg-slate-800/60 rounded-xl p-6 mb-4 items-center">
          <Text className="text-slate-400 text-sm">{language === 'en' ? 'Active Cases' : 'الحالات النشطة'}</Text>
          <Text className="text-white text-5xl font-bold mt-2">{activeForms.length}</Text>
        </View>

        {/* Completed Cases */}
        <View className="bg-slate-800/60 rounded-xl p-4 mb-6 flex-row items-center">
          <View className="w-12 h-12 bg-slate-500 rounded-full items-center justify-center">
            <Check size={24} color="#fff" />
          </View>
          <View className="flex-1 ml-4">
            <Text className="text-slate-400 text-sm">{language === 'en' ? 'Completed Cases' : 'الحالات المكتملة'}</Text>
          </View>
          <Text className="text-white text-3xl font-bold">{completedCount}</Text>
        </View>

        {/* Priority Breakdown */}
        <Text className="text-slate-400 text-sm mb-3">{language === 'en' ? 'Active by Priority' : 'النشطة حسب الأولوية'}</Text>
        <View className="gap-3">
          {stats.map((stat) => (
            <View
              key={stat.label}
              className="bg-slate-800/60 rounded-xl p-4 flex-row items-center"
            >
              <View className={`w-12 h-12 ${stat.color} rounded-full items-center justify-center`}>
                <stat.icon size={24} color="#fff" />
              </View>
              <View className="flex-1 ml-4">
                <Text className="text-slate-400 text-sm">{stat.label}</Text>
              </View>
              <Text className="text-white text-3xl font-bold">{stat.count}</Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

// Info Section
function ResponderInfoSection({ t, language }: { t: (key: string) => string; language: string }) {
  const router = useRouter();

  const priorityActions = language === 'en' ? [
    {
      priority: 'Critical',
      color: 'bg-red-500',
      icon: AlertCircle,
      summary: 'Requires immediate, time-intensive medical attention. Relocate to safe zone hospital immediately.',
      actions: [
        'Stabilize immediately: control bleeding, maintain airway and breathing, monitor vital signs.',
        'Urgent evacuation: prioritize urgent medical transport to the nearest functioning facility.',
        'Provide IV fluids (for dehydration/shock) and oxygen support if available.',
        '(Dependent on situation) Prepare for emergency birth/active labor if necessary—ensure clean delivery environment.',
      ],
    },
    {
      priority: 'High',
      color: 'bg-orange-500',
      icon: AlertTriangle,
      summary: 'Urgent attention needed. Seek medical care within 5-7 hours.',
      actions: [
        'Continuous monitoring: assess blood pressure, bleeding, pain, or infection signs.',
        'Administer basic treatments: oral rehydration, antibiotics (if trained/authorized), iron supplements.',
        'Coordinate evacuation within hours to a safer medical post or clinic.',
        'Record and relay data through Aidora or other communication channels for medical history.',
      ],
    },
    {
      priority: 'Medium',
      color: 'bg-yellow-500',
      icon: Info,
      summary: 'Should be evaluated soon. Schedule appointment within days.',
      actions: [
        'Provide nutritional and hydration support—safe water, high‑protein foods, prenatal vitamins.',
        'Observe regularly (daily if possible) for worsening symptoms or signs of preterm labor.',
        'Provide mental and health advice.',
        'Monitor condition, and follow up, looking for escalation towards high priority.',
      ],
    },
    {
      priority: 'Low',
      color: 'bg-green-500',
      icon: CheckCircle,
      summary: 'Routine follow-up. Standard care. Relocate to prevent further complications.',
      actions: [
        'Encourage rest, nutrition, and hygiene maintenance.',
        'Provide health education—danger signs to watch for and when to seek help.',
        'Regular follow‑up (weekly or biweekly) to reassess condition and update Aidora records.',
        'Community network support: link with nearby responders or safe shelters for continuity of care.',
      ],
    },
  ] : [
    {
      priority: 'حرج',
      color: 'bg-red-500',
      icon: AlertCircle,
      summary: 'يتطلب اهتمامًا طبيًا فوريًا ومكثفًا. انتقل إلى مستشفى المنطقة الآمنة فورًا.',
      actions: [
        'استقرار فوري: السيطرة على النزيف، الحفاظ على مجرى الهواء والتنفس، مراقبة العلامات الحيوية.',
        'إخلاء عاجل: إعطاء الأولوية للنقل الطبي العاجل إلى أقرب منشأة عاملة.',
        'توفير السوائل الوريدية (للجفاف/الصدمة) ودعم الأكسجين إذا كان متاحًا.',
        '(حسب الحالة) الاستعداد للولادة الطارئة/المخاض النشط إذا لزم الأمر—ضمان بيئة ولادة نظيفة.',
      ],
    },
    {
      priority: 'عالي',
      color: 'bg-orange-500',
      icon: AlertTriangle,
      summary: 'يحتاج إلى اهتمام عاجل. اطلب الرعاية الطبية خلال 5-7 ساعات.',
      actions: [
        'المراقبة المستمرة: تقييم ضغط الدم والنزيف والألم أو علامات العدوى.',
        'إعطاء العلاجات الأساسية: معالجة الجفاف عن طريق الفم، المضادات الحيوية (إذا كنت مدربًا/مخولًا)، مكملات الحديد.',
        'تنسيق الإخلاء خلال ساعات إلى مركز طبي أو عيادة أكثر أمانًا.',
        'تسجيل البيانات ونقلها عبر Aidora أو قنوات اتصال أخرى للتاريخ الطبي.',
      ],
    },
    {
      priority: 'متوسط',
      color: 'bg-yellow-500',
      icon: Info,
      summary: 'يجب تقييمه قريبًا. حدد موعدًا خلال أيام.',
      actions: [
        'توفير الدعم الغذائي والترطيب—مياه آمنة، أطعمة غنية بالبروتين، فيتامينات ما قبل الولادة.',
        'المراقبة بانتظام (يوميًا إن أمكن) لتفاقم الأعراض أو علامات الولادة المبكرة.',
        'تقديم نصائح الصحة النفسية والجسدية.',
        'مراقبة الحالة والمتابعة، والبحث عن التصعيد نحو الأولوية العالية.',
      ],
    },
    {
      priority: 'منخفض',
      color: 'bg-green-500',
      icon: CheckCircle,
      summary: 'متابعة روتينية. رعاية قياسية. انتقل لمنع المزيد من المضاعفات.',
      actions: [
        'تشجيع الراحة والتغذية والحفاظ على النظافة.',
        'توفير التثقيف الصحي—علامات الخطر التي يجب مراقبتها ومتى يجب طلب المساعدة.',
        'متابعة منتظمة (أسبوعية أو كل أسبوعين) لإعادة تقييم الحالة وتحديث سجلات Aidora.',
        'دعم شبكة المجتمع: الربط مع المستجيبين القريبين أو الملاجئ الآمنة لاستمرارية الرعاية.',
      ],
    },
  ];

  return (
    <ScrollView className="flex-1 px-4" showsVerticalScrollIndicator={false}>
      <View className="py-4">
        <Text className="text-white text-xl font-bold mb-6">{t('responderActions')}</Text>

        {priorityActions.map((item, index) => (
          <View key={index} className="bg-slate-800/60 rounded-xl mb-4 overflow-hidden">
            <View className="flex-row items-center p-4 border-b border-slate-700/50">
              <View className={`w-10 h-10 ${item.color} rounded-full items-center justify-center`}>
                <item.icon size={20} color="#fff" />
              </View>
              <Text className="text-white font-bold text-lg ml-3">{item.priority}</Text>
            </View>
            <View className="p-4">
              <Text className="text-teal-400 text-sm font-medium mb-3">{item.summary}</Text>
              {item.actions.map((action, actionIndex) => (
                <View key={actionIndex} className="flex-row mb-2">
                  <Text className="text-slate-400 text-sm mr-2">{actionIndex + 1}.</Text>
                  <Text className="text-slate-300 text-sm flex-1">{action}</Text>
                </View>
              ))}
            </View>
          </View>
        ))}

        {/* Logout Button */}
        <Pressable
          onPress={() => router.replace('/')}
          className="mt-4 mb-8 bg-slate-700 py-4 rounded-xl flex-row items-center justify-center"
        >
          <LogOut size={20} color="#ef4444" />
          <Text className="text-red-400 font-semibold ml-2">{t('logout')}</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

export default function ResponderScreen() {
  const { t, language } = useLanguage();
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');

  const tabs = [
    { key: 'dashboard' as Tab, label: t('dashboard'), icon: LayoutDashboard },
    { key: 'qrcode' as Tab, label: t('qrCode'), icon: QrCode },
    { key: 'status' as Tab, label: t('status'), icon: BarChart3 },
    { key: 'info' as Tab, label: t('info'), icon: Info },
  ];

  return (
    <View className="flex-1 bg-slate-900">
      <LinearGradient
        colors={['#1e3a5f', '#1e293b', '#0f172a']}
        style={{ flex: 1 }}
      >
        <SafeAreaView className="flex-1" edges={['top']}>
          {/* Navigation Pane */}
          <View className="px-4 pt-2 pb-3">
            <View className="flex-row bg-slate-800/80 rounded-xl p-1">
              {tabs.map((tab) => (
                <Pressable
                  key={tab.key}
                  onPress={() => setActiveTab(tab.key)}
                  className={`flex-1 py-3 rounded-lg items-center ${
                    activeTab === tab.key ? 'bg-blue-500' : ''
                  }`}
                >
                  <tab.icon
                    size={18}
                    color={activeTab === tab.key ? '#fff' : '#64748b'}
                  />
                  <Text
                    className={`text-xs font-medium mt-1 ${
                      activeTab === tab.key ? 'text-white' : 'text-slate-400'
                    }`}
                  >
                    {tab.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Content */}
          {activeTab === 'dashboard' && <DashboardSection t={t} language={language} />}
          {activeTab === 'qrcode' && <QRScannerSection t={t} />}
          {activeTab === 'status' && <StatusSummarySection t={t} language={language} />}
          {activeTab === 'info' && <ResponderInfoSection t={t} language={language} />}
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}
