# Aidora - Maternal Health Support App

A mobile application designed to help pregnant mothers in crisis zones track their health status and connect with first responders for emergency medical care.

## Features

### For Mothers
- **No login required** - Direct access to form submission
- **Comprehensive health form** with expandable sections:
  - Name, Age, Trimester
  - Number of babies conceived
  - Common symptoms (bleeding, headache, swelling, etc.)
  - Health conditions (diabetes, cancer, kidney disease, etc.)
  - Location conditions (displaced, food shortage, exposure to bombing, etc.)
  - Additional information
- **Priority calculation** based on symptoms and conditions (Critical, High, Medium, Low)
- **Your Status** section showing submitted forms with QR codes for sharing
- **Information** section with definitions and explanations

### For First Responders
- **Login required** for access
- **Dashboard** showing all received forms sorted by priority
- **QR Scanner** to receive mother forms via QR code
- **Status Summary** with case counts by priority level
- **Info** section with detailed response actions for each priority level

### Language Support
- English and Arabic translations
- Language selector on home screen

## Tech Stack
- Expo SDK 53
- React Native 0.76.7
- TypeScript
- NativeWind (TailwindCSS)
- Zustand for state management
- React QR Code for QR generation
- Expo Camera for QR scanning

## Screens
1. **Home** - Role selection (Mother/First Responder) with language toggle
2. **Mother** - Form, Your Status, and Information sections
3. **Responder Login** - Email/password login
4. **Responder** - Dashboard, QR Scanner, Status, and Info sections

## Data Storage
All data is stored locally using AsyncStorage via Zustand persist middleware.
